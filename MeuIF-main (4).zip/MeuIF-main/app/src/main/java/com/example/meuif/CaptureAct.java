package com.example.meuif;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity
{
}
