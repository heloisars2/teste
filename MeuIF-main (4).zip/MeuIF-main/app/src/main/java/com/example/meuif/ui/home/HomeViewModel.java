package com.example.meuif.ui.home;

import static android.app.PendingIntent.getActivity;
import static android.provider.Settings.System.getString;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.meuif.R;

public class HomeViewModel extends ViewModel {


    public HomeViewModel(  ) {

    }



}