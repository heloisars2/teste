package com.example.meuif.sepae.Portaria;

public interface OnFiltroSelectedListener {
    void onObjSelected(ModelFiltroPortaria modelFiltroPortaria);
}
