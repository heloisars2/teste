package com.example.meuif.sepae.Merenda;

public interface OnTurmaSelectedListener {
    void onTurmaSelected(String turma);
}
