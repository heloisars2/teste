package com.example.meuif;

import android.app.Activity;

public class CustomListView extends Activity {
}
